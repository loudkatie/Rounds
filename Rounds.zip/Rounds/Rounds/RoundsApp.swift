//
//  RoundsApp.swift
//  Rounds AI
//
//  Your medical appointment AI assistant
//

import SwiftUI

@main
struct RoundsApp: App {

    var body: some Scene {
        WindowGroup {
            RootView()
        }
    }
}
